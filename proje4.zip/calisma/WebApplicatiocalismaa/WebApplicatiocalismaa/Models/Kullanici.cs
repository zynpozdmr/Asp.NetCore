﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplicatiocalismaa.Models
{
    public class Kullanici
    {
        [Required(ErrorMessage ="bu alan boş bırakılamaz")]
        [MinLength(2,ErrorMessage ="ad en az 2 karakter uzunluğunda olmalı")]
        
        
        public string Ad { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		public string Soyad { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
        [EmailAddress(ErrorMessage ="lütfen emailinizi mail formatında giriniz")]
		public string Eposta { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		
		public string Sifre { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		[Compare("Sifre",ErrorMessage ="şifreler uyuşmuyor")]
		public string SifreTekrar { get; set; }
    }
}
