﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplicatiocalismaa.Models;

namespace WebApplicatiocalismaa.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}


/* 
 using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Emit;
using System.Reflection;
using WebApplicatiocalismaa.Models;


namespace WebApplicatiocalismaa.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult KayitOl()
        {
            return View();
        }

        [HttpPost]
        public IActionResult KayitOl(Kullanici kullanici)
        {
            if (!ModelState.IsValid)
            {
                return View(kullanici);
            }
            
            return RedirectToAction("Index","Home");
        }
    }
}

//------------------------
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplicatiocalismaa.Models
{
	public class Kullanici
	{
		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		[MinLength(2, ErrorMessage = "ad en az 2 karakter uzunluğunda olmalı")]


		public string Ad { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		public string Soyad { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		[EmailAddress(ErrorMessage = "lütfen emailinizi mail formatında giriniz")]
		public string Eposta { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]

		public string Sifre { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılamaz")]
		[Compare("Sifre", ErrorMessage = "şifreler uyuşmuyor")]
		public string SifreTekrar { get; set; }
	}
}

//-----------------------------------------------

@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers;
@model WebApplicatiocalismaa.Models.Kullanici

<h1> Örnek Kayıt Ol Sayfası</h1>

<form asp-action="KayitOl" asp-controller="Kullanici" method="post">
	<label asp-for="Ad">Adınız:</ label >
	< input asp -for= "Ad" />
	< span asp - validation -for= "Ad" ></ span >
	< br />

	< label asp -for= "Soyad" > Soyadınız:</ label >
	< input asp -for= "Soyad" />
	< span asp - validation -for= "Soyad" ></ span >
	< br />
	< label asp -for= "Eposta" > Eposta adresiniz:</ label >
	< input asp -for= "Eposta" type = "email" />
	< span asp - validation -for= "Eposta" ></ span >
	< br />
	< label asp -for= "Sifre" > Sifreniz:</ label >
	< input asp -for= "Sifre" type = "password" />
	< span asp - validation -for= "Sifre" ></ span >
	< br />
	< label asp -for= "SifreTekrar" > Sifrenizi Tekrar Girin:</ label >
	< input asp -for= "SifreTekrar" type = "password" />
	< span asp - validation -for= "SifreTekrar" ></ span >
	< br />
	< button type = "submit" > Kayıt Ol </ button >

</ form >

< a asp - controller = "Home" asp - action = "Index" > Anasayfa için tıklayınız </ a >
< br />
< a asp - controller = "Home" asp - action = "Privacy" > Privacy için tıklayınız </ a >
 
 */