﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Emit;
using System.Reflection;
using WebApplicatiocalismaa.Models;


namespace WebApplicatiocalismaa.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult KayitOl()
        {
            return View();
        }

        [HttpPost]
        public IActionResult KayitOl(Kullanici kullanici)
        {
            if (!ModelState.IsValid)
            {
                return View(kullanici);
            }
            
            return RedirectToAction("Index","Home");
        }
    }
}

