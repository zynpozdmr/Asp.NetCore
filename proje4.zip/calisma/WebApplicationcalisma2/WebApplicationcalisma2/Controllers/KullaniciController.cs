﻿using Microsoft.AspNetCore.Mvc;
using WebApplicationcalisma2.Models;

namespace WebApplicationcalisma2.Controllers
{
	public class KullaniciController : Controller
	{
		public IActionResult GirisYap()
		{
			return View();
		}

		[HttpPost]
		public IActionResult GirisYap(Kullanici K1)
		{
			if (!ModelState.IsValid)
			{
				return View(K1);
			}

			return RedirectToAction("Index", "Home");
		}
	}
}
