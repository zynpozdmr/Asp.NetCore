﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace WebApplicationcalisma2.Models
{
	public class Kullanici
	{
		[Required(ErrorMessage ="bu alan boş bırakılmamalııı")]
		public string Ad { get; set; }
		[Required(ErrorMessage = "bu alan boş bırakılmamalııı")]
		public string Soyad { get; set; }
		[Required(ErrorMessage = "bu alan boş bırakılmamalııı")]
		[EmailAddress(ErrorMessage ="doğru formatta girin")]
		public string EPosta { get; set; }
		[Required(ErrorMessage = "bu alan boş bırakılmamalııı")]
		public string Sifre { get; set; }

		[Required(ErrorMessage = "bu alan boş bırakılmamalııı")]
		[Compare("Sifre",ErrorMessage ="şifrenizle uyuşmuyorr")]
		public string SifreDogrulama { get; set; }

    }
}
